# 2nd Edition, renamed after "Edition"

A modern theme for if.toosadtowrite.com based on the newsletter theme "Edition" for [Ghost](https://github.com/TryGhost/Ghost).

# version 2.0.0



# Copyright & License

Copyright (c) 2013-2023 Ghost Foundation - Released under the [MIT license](LICENSE).
